'use strict';

/**
 * @ngdoc function
 * @name telehealthApp.controller:ScheduleCtrl
 * @description
 * # ScheduleCtrl
 * Controller of the telehealthApp
 */
angular.module('telehealthApp')

  .controller('ScheduleCtrl', function ($scope) {


    
    
  });

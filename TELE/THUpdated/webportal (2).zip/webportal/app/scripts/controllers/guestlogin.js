'use strict';

/**
 * @ngdoc function
 * @name telehealthApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the telehealthApp
 */
angular.module('telehealthApp')

  .controller('GuestloginCtrl', function ($scope, restcalls, $location) {


    $scope.resetForm = function() {

    	document.getElementById("myForm").reset() ;

    }

    $scope.numberPattern = "\\d+" ;

    $scope.totalDays = 31 ;
    $scope.totalMonths = 12 ;
    $scope.totalyears = 90 ;


    $scope.days = [] ;

    for(var i=0; i<$scope.totalDays ; i++){
    	$scope.days.push(i+1);
    }

    $scope.months = [] ;

    for(var i=0; i< $scope.totalMonths; i++){
    	$scope.months.push(i+1);
    }


    $scope.years = [] ;

    var currentyear = new Date().getFullYear();

    for(var i=currentyear; i > currentyear - $scope.totalyears; i--){

    	$scope.years.push(i);

    }

    $scope.states = [ "Andra Pradesh","Arunachal Pradesh","Assam","Bihar","Chhattisgarh","Goa","Gujarat","Haryana","Himachal Pradesh","Jammu and Kashmir",
    "Jharkhand", "Karnataka", "Kerala", "Madya Pradesh", "Maharashtra", "Manipur", "Meghalaya","Mizoram", "Nagaland", "Orissa", "Punjab", "Rajasthan",
    "Sikkim", "Tamil Nadu","Telangana", "Tripura", "Uttaranchal", "Uttar Pradesh", "West Bengal" ];

    $scope.cities = ["Hyderabad", "Itangar", "Dispur", "Patna", "Raipur", "Panaji", "Gandhinagar", "Chandigarh", "Shimla", "Srinagar and Jammu",
    "Ranchi", "Bangalore", "Thiruvananthapuram", "Bhopal", "Mumbai", "Imphal", "Shillong", "Aizawi", "Kohima", "Bhubaneshwar", "Chandigarh", "Jaipur",
    "Gangtok", "Chennai", "Agartala", "Dehradun", "Lucknow", "Kolkata"];

    $scope.success = function() {
        var userObject = {
            "firstname" : $scope.user.firstname,
            "lastname" : $scope.user.lastname,
            "DOB_mm" : $scope.user.month,
            "DOB_dd" : $scope.user.day,
            "DOB_yyyy" : $scope.user.year,
            "mailid" : $scope.user.email,
            "mobileno" : $scope.user.contactNumber,
            "contact_person" : $scope.user.contactPerson,
            "alternate_contact" : $scope.user.contactNumberOther,
            "address_line_1" : $scope.user.address1,
            "address_line_2" : $scope.user.address2,
            "location" : $scope.user.state,
            "city" : $scope.user.city,
            "zip_code" : $scope.user.zip
        }

        $scope.dataLoading = true;
        restcalls.guestlogin(userObject).then( function(response) {
            console.log("hi-------\n" + response);
            $location.path('/success');
        });
        

    };

    
  });

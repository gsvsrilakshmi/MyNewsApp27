'use strict';

/**
 * @ngdoc function
 * @name telehealthApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the telehealthApp
 */
angular.module('telehealthApp')
  .controller('formController', function (restcalls,$scope, $filter) {

    $scope.data = {};

     // function to process the form
    $scope.processForm = function() {
    };
    
        // TO Get Reasons List
        restcalls.getReasonsList().then(function(response){
            $scope.reasons = response.data;
            $scope.selected = $scope.reasons[""];
        });

        // TO Get Locations List
        restcalls.getLocations().then(function(response){
            $scope.states = response.data;
            $scope.data.searchTextSelected = '';
        });

var currentDate = moment();

var firstWeek = moment().add(1, 'w');
var secondWeek = moment().add(2, 'w');
var firsttabdate=currentDate.clone();
var secondtabDate=firstWeek.clone();
var thirdtabDate=secondWeek.clone();

$scope.firstTab=getTabDate(firsttabdate);
$scope.secondTab=getTabDate(secondtabDate);
$scope.thirdTab=getTabDate(thirdtabDate);

function getTabDate(tabdate){
   return tabdate.format('MMM')+" "+tabdate.startOf('week').format('DD')+" - "+tabdate.endOf('week').format('DD')+", "+tabdate.format('YYYY');
};

    var fnWeekDays = function(dt) {

        var currentDate = dt;
        var weekStart = currentDate.clone().startOf('week');
        var weekEnd = currentDate.clone().endOf('week');

        var days = [];
        for (var i = 0; i <= 6; i++) {
            days.push(moment(weekStart).add(i, 'days').format("dddd MMMM Do"));
        };
        return days;
    }
    
    $scope.weekDays = fnWeekDays(currentDate);

    $scope.currentWeekDates =function(Week1){
        console.log($scope.data.searchTextSelected + "---selected");
        $scope.weekDays = fnWeekDays(currentDate);
        $scope.weekData=$scope.firstWeekData;
    };

    $scope.firstWeekDates =function(Week2){
        $scope.weekDays=fnWeekDays(firstWeek);
        $scope.weekData= $scope.secondWeekData;
   };

    $scope.secondWeekDates = function(week3){
        $scope.weekDays =fnWeekDays(secondWeek);
        $scope.weekData=$scope.thirdWeekData;
    }; 

    $scope.getSlotsByLocation = function(){
        restcalls.getAllSlots($scope.data.searchTextSelected).then(function(response){
        var threeWeeksData = response.data;
          $scope.firstWeekData=addDummyDataToWeek(threeWeeksData.week1);
          $scope.weekData=$scope.firstWeekData;
          $scope.secondWeekData=threeWeeksData.week2;
          $scope.thirdWeekData=threeWeeksData.week3;
        });     
    };

          function addDummyDataToWeek(weekData){
            var requiredDummyObjects=7-weekData.length;
            var Dummies=[];
            for(var i=requiredDummyObjects;i>0;i--){
                var date = new Date();
                date.setDate(date.getDate()-i);
                var dummy={
            "slots": [
                {
                    "available": "Blocked",
                    "start_Time": "2 PM",
                    "end_Time": "5 PM",
                    "slot_id": 3
                },
                {
                    "available": "Blocked",
                    "start_Time": "11 AM",
                    "end_Time": "2 PM",
                    "slot_id": 2
                },
                {
                    "available": "Blocked",
                    "start_Time": "8 AM",
                    "end_Time": "11 AM",
                    "slot_id": 1
                }
            ],
            "date": date.toString()
        };
            Dummies.push(dummy);
            }
            angular.forEach(weekData, function(day){
            Dummies.push(day);
        });
            return Dummies;


          }

          $scope.toggleButton=function(available){
            if(available=='Yes'){
                available='Selected';
            }
            else{
                available='Yes';
            }
            return available;
          };
  });

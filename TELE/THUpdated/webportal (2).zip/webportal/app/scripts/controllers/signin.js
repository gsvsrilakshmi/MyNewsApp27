'use strict';

/**
 * @ngdoc function
 * @name telehealthApp.controller:SigninCtrl
 * @description
 * # SigninCtrl
 * Controller of the telehealthApp
 */
angular.module('telehealthApp')
  .controller('SigninCtrl', function ($scope, restcalls, $location) {

  	$scope.login = function () {
            $scope.dataLoading = true;
            var userObject = {
            	"username" : $scope.username,
            	"password" : $scope.password
            }
            restcalls.login(userObject).then(function(response) {
                if(response.data.status == 'success') {
                    $location.path('/success');
                } else {
                    $scope.error = response.data.Message;
                    $scope.dataLoading = false;
                }
            });
        };
    
  });
